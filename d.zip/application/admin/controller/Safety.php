<?php
namespace app\admin\controller;
use think\Db;

class Safety extends Base
{

}
